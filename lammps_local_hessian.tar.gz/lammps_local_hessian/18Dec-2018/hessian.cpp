/* ----------------------------------------------------------------------
   LAMMPS - Large-scale Atomic/Molecular Massively Parallel Simulator
   http://lammps.sandia.gov, Sandia National Laboratories
   Steve Plimpton, sjplimp@sandia.gov

   Copyright (2003) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.

   See the README file in the top-level LAMMPS directory.
------------------------------------------------------------------------- */

#include "lmptype.h"
#include <mpi.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "hessian.h"
#include "universe.h"
#include "output.h"
#include "thermo.h"
#include "timer.h"
#include "neighbor.h"
#include "atom.h"
#include "atom_vec.h"
#include "error.h"
#include "update.h"
#include "memory.h"
#include "domain.h"
#include "modify.h"
#include "force.h"
#include "pair.h"
#include "bond.h"
#include "angle.h"
#include "dihedral.h"
#include "improper.h"
#include "kspace.h"
#include "comm.h"
#include "group.h"
#include "fix.h"
#include "min.h"
#include "finish.h"
#include "displace_atoms.h"
#include <iostream>
#include <sstream>
#include <fstream>
#include <iomanip> 

using namespace std;
using namespace LAMMPS_NS;

/* ---------------------------------------------------------------------- */

HESSIAN::HESSIAN(LAMMPS *lmp) : Pointers(lmp) {}
/* ---------------------------------------------------------------------- */

/* ---------------------------------------------------------------------- */

void HESSIAN::command(int narg, char **arg) {
  
  if (narg != 6) error->all(FLERR,"Illegal hessian command");

  if (domain->box_exist == 0)
    error->all(FLERR,"Hessian command before simulation box is defined");

  int igroup = group->find(arg[0]);
  if (igroup == -1) error->all(FLERR,"Could not find hessian group ID");
  int groupbit = group->bitmask[igroup];
  int natomgroup = group->count(igroup);
  double epsilon = atof(arg[1]);
  double iepsilon = 1 / epsilon;
  int ndofs = natomgroup * 3;
  update->etol = force->numeric(FLERR,arg[2]);
  update->ftol = force->numeric(FLERR,arg[3]);
  update->nsteps = force->inumeric(FLERR,arg[4]);
  update->max_eval = force->inumeric(FLERR,arg[5]);

  /* tags must be defined and consecutive. */
  if (atom->tag_enable == 0)
    error->all(FLERR,
               "Cannot use hessian unless atoms have IDs");
  if (atom->tag_consecutive() == 0)
    error->all(FLERR,
               "Atom IDs must be consecutive for hessian");
  
  if (update->etol < 0.0 || update->ftol < 0.0)
    error->all(FLERR,"Illegal hessian command");

  update->whichflag = 2;
  update->minimize_style = "cg"; 
  update->beginstep = update->firststep = update->ntimestep;
  update->endstep = update->laststep = update->firststep + update->nsteps;
  if (update->laststep < 0)
    error->all(FLERR,"Too many iterations");

  if (lmp->kokkos)
    error->all(FLERR,"Cannot yet use hessian with Kokkos");

  /* these values will change if the system size changes. */
  double *x_ref, *fglobal_new_pos, *fglobal_new_neg, *fglobal_copy, *fglobal_ref, *hessian; 
  x_ref = fglobal_new_pos = fglobal_new_neg = fglobal_copy = NULL;
  hessian = NULL;
  bigint nhessianelements = ndofs * ndofs;
  x_ref = (double *) malloc (atom->natoms * 3 * sizeof (double));   
  fglobal_new_pos = (double *) malloc (ndofs * sizeof (double));   
  fglobal_new_neg = (double *) malloc (ndofs * sizeof (double));   
  fglobal_copy = (double *) malloc (ndofs * sizeof (double));   
  fglobal_ref = (double *) malloc (ndofs * sizeof (double));   
  
  hessian = (double *) malloc (nhessianelements * sizeof (double));
  
  /* these variables have the same size regardless of the size of the system */
  double *ftotSpring;
  ftotSpring= (double *) malloc (3 * sizeof (double));
  
  double* xcm_init;
  xcm_init = (double *) malloc (3 * sizeof (double));
   
  /* set up a group of atom that are in the environment*/
  char **group_arg = new char*[4];
  group_arg[0] = (char *) "bg";
  group_arg[1] = (char *) "subtract";
  group_arg[2] = (char *) "all";
  group_arg[3] = (char *) group->names[igroup];
  group->assign(4,group_arg);
  delete [] group_arg; 
  
  int alligroup=group->find("all");
  int bgigroup=group->find("bg");
  
 /* no energy or virial updates. */
  int eflag = 0;
  int vflag = 0;
   
  /* allow pair and kspace compute to be turned off via modify flags. */
  int pair_compute_flag, kspace_compute_flag;
  if (force->pair && force->pair->compute_flag)
    pair_compute_flag = 1;
  else
    pair_compute_flag = 0;
  if (force->kspace && force->kspace->compute_flag)
    kspace_compute_flag = 1;
  else
   kspace_compute_flag = 0;

  //print out hessian 
   ofstream myfile;
   myfile.open ("hessian.out");

  /* a lot of the hessian will be zero, so start there. */
  memset (hessian, 0, nhessianelements * sizeof(double));
  int global_atom_a=-1,index_a,index_b,global_atom_b=-1;
  double difference;
 
  /* get the initial COM of all atoms in the system */
  group->xcm(alligroup,group->mass(alligroup),xcm_init);
  double xi,yi,zi;
  xi=xcm_init[0];
  yi=xcm_init[1];
  zi=xcm_init[2];
  
  /* attach a spring to the COM of the system */ 
  char **argsSpring = new char*[9];
  char charray3[200], charray4[200], charray5[200];
  argsSpring[0] = (char *) "teth";
  argsSpring[1] = (char *) "all";
  argsSpring[2] = (char *) "spring";
  argsSpring[3] = (char *) "tether"; 
  argsSpring[4] = (char *)  "1000.0"; // be careful with the units that is being used.
  sprintf(charray3, "%2.8f", xi );
  argsSpring[5] = (char *) charray3 ;
  sprintf(charray4, "%2.8f", yi );
  argsSpring[6] = (char *) charray4;
  sprintf(charray5, "%2.8f", zi );
  argsSpring[7] =  (char *) charray5;
  argsSpring[8] =  (char *) "0.0";
  
  // implement fix spring
  modify->add_fix(9,argsSpring);
  fix_spring = (Fix *) modify->fix[modify->nfix-1];
  fix_spring->init();
  fix_spring->min_setup(vflag);
 
  //add energy of spring to the objective function of minimization
  char **argsMod = new char*[2];
  argsMod[0] = (char *) "energy";
  argsMod[1] = (char *) "yes";
  fix_spring->modify_params(2,argsMod);

  double masstotal,massone;
  masstotal=group->mass(alligroup);


/*start hessian calucaltion*/  
for (int atom_id_1=1;atom_id_1<=atom->natoms;atom_id_1++){//first loop over atoms to move them
if (atom->mask[atom->map(atom_id_1)] & groupbit){//if over group member
global_atom_a++;
for (int dim_id_1=0;dim_id_1<domain->dimension;dim_id_1++){//firs loop over dimension
  /* set the initial fglobal_new to zero */
  memset (&fglobal_new_pos[0], 0, natomgroup * 3 * sizeof (double));
  memset (&fglobal_new_neg[0], 0, natomgroup * 3 * sizeof (double));
for (int dir=-1;dir<2;dir+=2 ){//loop over dir pos or neg
 
  
  /* set up the setforce fix to prevent neighbor atoms to move during outside atoms minimization */
  char **args2 = new char*[6];
  args2[0] = (char *) "freeze";
  args2[1] = (char *) group->names[igroup];
  args2[2] = (char *) "setforce";
  args2[3] = (char *) "0.0";
  args2[4] = (char *) "0.0";
  args2[5] = (char *) "0.0";
  modify->add_fix(6,args2);
  delete [] args2; 
  fix_setforce = (Fix *) modify->fix[modify->nfix-1];
  fix_setforce->init();

  /* set up a group of atom to move*/
  char charray[200];
  sprintf(charray, "%d", atom_id_1);
  char **group_arg = new char*[3];
  group_arg[0] = (char *) "move";
  group_arg[1] = (char *) "id";
  group_arg[2] = (char *) charray;
  group->assign(3,group_arg);
 
  //move the corresponding position in forward direction 
  char **move_arg = new char*[7];
  move_arg[0] = (char *) "move";
  move_arg[1] = (char *) "move";
  sprintf(charray, "%2.8f", dir * epsilon);

  if (dim_id_1 == 0) { move_arg[2] = (char *) charray; move_arg[3] = (char *) "0.0"; move_arg[4] = (char *) "0.0";}
  else if (dim_id_1 == 1){move_arg[2] = (char *) "0.0"; move_arg[3] = (char *) charray; move_arg[4] = (char *) "0.0";}
  else {move_arg[2] = (char *) "0.0"; move_arg[3] = (char *) "0.0"; move_arg[4] = (char *) charray;}
  move_arg[5] = (char *) "units";
  move_arg[6] = (char *) "box";
  dis = new DisplaceAtoms(lmp);
  dis->command(7,move_arg);
  
///////////////////////////////////////
  /* start minimization process on the background atoms */
  double einitial,efinal,fnorm2_initial,fnorm2_final,fnorminf_initial,fnorminf_final; 
    //we have to reinitiate update->nsteps becuase after update->minimize->run is conducted, update->nsteps is set to update->niter and this inside the loop will prevent the minimizaer to reach the accuracy that we need.
  update->nsteps = force->inumeric(FLERR,arg[4]);
     
  lmp->init();      //It has update->init() and becuase we set whichflag=2 it will do update->minimize->init(). 		    //It has modify->init() which initiates the list of fixed to be included in the run
  update->minimize->setup();
  timer->init();
  timer->barrier_start();
  //impelemnt the fix setforce
  //It calls post_force //In update->minimize->setup(), the modify->setup() is called, which basically do all the relevant fixes fix->setup(), so this line is redundant 
  //fix_setforce->setup(vflag); 
  
  fnorm2_initial=sqrt(update->minimize->fnorm_sqr());
  fnorminf_initial= update->minimize->fnorm_inf();
  einitial=update->minimize->einitial;

  //run minimization  
  update->minimize->run(update->nsteps);
  timer->barrier_stop();
   
  fnorm2_final=sqrt(update->minimize->fnorm_sqr());
  fnorminf_final= update->minimize->fnorm_inf();

  //print out minimization status
  cout<<"Stopping criterion = \t"<<update->minimize->stopstr<<endl;
  cout<<"Force two-norm initial, final on background atoms\t";
  cout<<fnorm2_initial<<"\t"<<fnorm2_final<<endl;
  cout<<"Force max component initial, final on background atoms\t";
  cout<<fnorminf_initial<<"\t"<<fnorminf_final<<endl;
  cout<<"Iterations, force evaluations = \t"<<update->minimize->niter<<"\t"<<update->minimize->neval<<endl;
 
  /* minimization is finished */
 
  //delete fix to get real forces
  modify->delete_fix("freeze"); //remove the fix from list, and atom->update_callback() 
  //standard force call to get the real forces
  timer->init();
  timer->barrier_start();
  update->minimize->run(1); 
  timer->barrier_stop();
  cout<<"Force two-norm and max component acting on all atoms including active region:\t";
  cout<<sqrt(update->minimize->fnorm_sqr())<<endl;
   // get the total force acting on all atoms due to the tethering of the spring 
   ftotSpring[0]= fix_spring->compute_vector(0); 
   ftotSpring[1]= fix_spring->compute_vector(1); 
   ftotSpring[2]= fix_spring->compute_vector(2); 
   ftotSpring[3]= fix_spring->compute_vector(3);
  /* construct fglobal_new by explicit scatter and reduce to preserve
   * atom-id ordering. */
  int reduce_n=-1;
  memset (&fglobal_copy[0], 0, natomgroup * 3 * sizeof (double));
  for (int k = 1; k <= atom->natoms; k++) {
    if (atom->mask[atom->map(k)] & groupbit) {
      if (atom->rmass) massone=atom->rmass[atom->map(k)];
      else massone=atom->mass[atom->type[atom->map(k)]];
      reduce_n++;
      for (int l = 0; l < domain->dimension; l++){
      fglobal_copy[idx2_c(reduce_n, l, natomgroup)] = atom->f[atom->map(k)][l] - ftotSpring[l] * massone/masstotal ;
      }
    }
  }
  reduce_n=-1;
  if (dir == -1){
  MPI_Allreduce (fglobal_copy, fglobal_new_neg, ndofs, MPI_DOUBLE, MPI_SUM, world);
  }else if (dir == 1){
  MPI_Allreduce (fglobal_copy, fglobal_new_pos, ndofs, MPI_DOUBLE, MPI_SUM, world);
  }
  
  
  /* put the position back */ 
  move_arg[0] = (char *) "move";
  move_arg[1] = (char *) "move";
  sprintf(charray, "%2.8f", -dir * epsilon);

  if (dim_id_1 == 0) { move_arg[2] = (char *) charray; move_arg[3] = (char *) "0.0"; move_arg[4] = (char *) "0.0";}
  else if (dim_id_1 == 1){move_arg[2] = (char *) "0.0"; move_arg[3] = (char *) charray; move_arg[4] = (char *) "0.0";}
  else {move_arg[2] = (char *) "0.0"; move_arg[3] = (char *) "0.0"; move_arg[4] = (char *) charray;}
  move_arg[5] = (char *) "units";
  move_arg[6] = (char *) "box";
  dis->command(7,move_arg);
  

  update->minimize->cleanup();
  efinal=update->minimize->efinal;
  cout<<std::setprecision(9)<<"Energy initial, final:\t"<<einitial<<"\t"<<efinal<<endl;
  Finish finish(lmp);
  finish.end(0);
  
  /*remove the corresponding atom from move group*/
  group_arg[0] = (char *) "move";
  group_arg[1] = (char *) "delete";
  group->assign(2,group_arg);
}//loop over direction pos or neg
      
      /* compute the difference (not using symmetry so we can do an in-place
       * reduciton). */      
      index_a = dim_id_1 + 3 * global_atom_a;
      cout<<"index_a = dim_id_1 + 3 * global_atom_a index_a dim_id_1 global_atom_a\t"<<index_a<<"\t"<<dim_id_1<<"\t"<<global_atom_a<<endl;
      for (int k = 1; k <= atom->natoms; k++) {
        if (atom->mask[atom->map(k)] & groupbit) {
          global_atom_b++;
          for (int l = 0; l < domain->dimension; l++) {
            index_b = l + 3 * global_atom_b;
            difference =
                fglobal_new_pos[idx2_c(global_atom_b, l, natomgroup)] - \
                fglobal_new_neg[idx2_c(global_atom_b, l, natomgroup)];
            hessian[idx2_c(index_a, index_b, ndofs)] =
               -0.5 * difference * iepsilon;
            myfile<<hessian[idx2_c(index_a, index_b, ndofs)]<<",";
          }
        }
      }
    myfile<<endl;
    global_atom_b=-1;
 
}//first loop over dimesion
}//if over group member
}//first loop over atom move

  /* only reduce the hessian to the root task. */
  MPI_Reduce(MPI_IN_PLACE, hessian, nhessianelements, MPI_DOUBLE, MPI_SUM, 0, world);
  
  update->whichflag = 0;
  update->firststep = update->laststep = 0;
  update->beginstep = update->endstep = 0;

  myfile.close();
  cout<<"Hessian succesfully written to hessian.out"<<endl;
 
  //delete fix spring
  modify->delete_fix("teth");

 //free memories
  free(x_ref);
  free(fglobal_new_pos);
  free(fglobal_new_neg);
  free(fglobal_copy);
  free(hessian);

}

void HESSIAN::force_clear() {
  size_t nbytes;
  int nlocal = atom->nlocal;

  nbytes = sizeof(double) * nlocal;
  if (force->newton) nbytes += sizeof(double) * atom->nghost;

  if (nbytes) memset (&atom->f[0][0], 0, 3 * nbytes);
}
