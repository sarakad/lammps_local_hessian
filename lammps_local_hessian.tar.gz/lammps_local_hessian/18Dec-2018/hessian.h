/* ----------------------------------------------------------------------
   LAMMPS - Large-scale Atomic/Molecular Massively Parallel Simulator
   http://lammps.sandia.gov, Sandia National Laboratories
   Steve Plimpton, sjplimp@sandia.gov

   Copyright (2003) Sandia Corporation.  Under the terms of Contract
   DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government retains
   certain rights in this software.  This software is distributed under
   the GNU General Public License.

   See the README file in the top-level LAMMPS directory.
------------------------------------------------------------------------- */

#ifdef COMMAND_CLASS

CommandStyle(hessian,HESSIAN)

#else

#ifndef LMP_HESSIAN_H
#define LMP_HESSIAN_H


//#include <stdio.h>
#include "pointers.h"
#include "fix.h"
#include "displace_atoms.h"
/* zero-based row- and column-major indexing macros for the hessian. */
#define idx2_r(i, j, ldj) ((i * ldj) + j)
#define idx2_c(i, j, ldi) ((j * ldi) + i)

namespace LAMMPS_NS {

  class HESSIAN : protected Pointers {
  public:
    HESSIAN(class LAMMPS *);
    void command(int, char **); //process hessian command
  
  private:
    Fix *fix_spring;
    Fix *fix_setforce;
    //Fix *fix_recenter;
    DisplaceAtoms *dis; 
    void force_clear();
 
  };

}

#endif
#endif
